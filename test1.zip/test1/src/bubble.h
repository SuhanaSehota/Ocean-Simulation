/*
 * bubble.h
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#ifndef BUBBLE_H_
#define BUBBLE_H_

class bubble {
public:
	bubble();
	virtual ~bubble();
};

#endif /* BUBBLE_H_ */
