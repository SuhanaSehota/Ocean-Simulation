/*
 * plant.h
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#ifndef PLANT_H_
#define PLANT_H_

class plant {
public:
	plant();
	virtual ~plant();
};

#endif /* PLANT_H_ */
