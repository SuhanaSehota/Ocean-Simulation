/*
 * fish.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */



#include "fish.h"

void fish1()
{
    // Body of the fish, changed color to blue
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_POLYGON);
    glVertex2f(270+a,350+aa);
    glVertex2f(300+a,325+aa);
    glVertex2f(370+a,350+aa);
    glVertex2f(300+a,375+aa);
    glEnd();

    // Tail, changed to a consistent color
    glBegin(GL_POLYGON);
    glColor3f(0.8, 0.3, 0.2);
    glVertex2f(360+a,350+aa);
    glVertex2f(405+a,370+aa);
    glVertex2f(395+a,350+aa);
    glVertex2f(405+a,327+aa);
    glEnd();

    // Top fin, changed shape and color
    glBegin(GL_TRIANGLES);
    glColor3f(0.8, 0.3, 0.2);
    glVertex2f(302+a,373+aa);
    glVertex2f(340+a,420+aa); // Extended the fin
    glVertex2f(320+a,360+aa);
    glEnd();

    // Bottom fin, changed shape and color
    glBegin(GL_TRIANGLES);
    glColor3f(0.8, 0.3, 0.2);
    glVertex2f(302+a,328+aa);
    glVertex2f(340+a,290+aa); // Extended the fin
    glVertex2f(320+a,340+aa);
    glEnd();

    // Eye of the fish
    glColor3f(0.0, 0.0, 0.0);
    glPointSize(4.0);
    glBegin(GL_POINTS);
    glVertex2f(280+a,355+aa);
    glEnd();
}

void fish2()
{
glColor3f(1.0,0.0,0.0);
  glBegin(GL_POLYGON);
     glVertex2f(70-b,145-bb);
  glColor3ub(rand()%500, rand()%500,0);
   glVertex2f(20-b,120-bb);
    glVertex2f(30-b,145-bb);
   glVertex2f(20-b,170-bb);


  glEnd();
  glColor3f(1.0,0.0,0.0);
    glBegin(GL_POLYGON);
   glVertex2f(65-b,145-bb);

   glVertex2f(125-b,170-bb);

   glVertex2f(165-b,145-bb);
   glVertex2f(125-b,120-bb);
  glEnd();

  glBegin(GL_TRIANGLES);
  glColor3ub(rand()%500, rand()%500,0);
    glVertex2f(126-b,168-bb);
   glColor3f(1.0,0.0,0.0);
   glVertex2f(110-b,155-bb);
    glVertex2f(85-b,195-bb);
 glEnd();
 glBegin(GL_TRIANGLES);
  glColor3ub(rand()%500, rand()%500,0);
    glVertex2f(126-b,122-bb);
   glColor3f(1.0,0.0,0.0);
glVertex2f(110-b,136-bb);
glVertex2f(85-b,95-bb);
  glEnd();
 glColor3f(0.0,0.0,0.0);
  glPointSize(4.0);
  glBegin(GL_POINTS);
  glVertex2f(150-b,149-bb);
  glEnd();

}

void goldfish() {
    glColor3ub(255, 165, 0); // Goldfish color (orange)

    // Body of the goldfish
    glBegin(GL_POLYGON);
    glVertex2f(200 + (a/0.5), 200 + (aa/0.5));
    glVertex2f(220 + (a/0.5), 190 + (aa/0.5));
    glVertex2f(240 + (a/0.5), 200 + (aa/0.5));
    glVertex2f(220 + (a/0.5), 210 + (aa/0.5));
    glEnd();

    // Tail of the goldfish
    glBegin(GL_POLYGON);
    glVertex2f(240 + (a/0.5), 200 + (aa/0.5));
    glVertex2f(260 + (a/0.5), 190 + (aa/0.5));
    glVertex2f(260 + (a/0.5), 210 + (aa/0.5));
    glEnd();

    // Eye of the goldfish
    glColor3ub(0, 0, 0); // Black color for the eye
    glPointSize(3.0);
    glBegin(GL_POINTS);
    glVertex2f(210 + (a/0.5), 200 + (aa/0.5));
    glEnd();
}

void anotherFish() {
    // Horizontal flip point (you can adjust this as needed)
    float flipX = 450;

    // Pink color for the fish
    glColor3ub(255, 192, 203); // Pink color

    // Body of the fish (larger)
    glBegin(GL_POLYGON);
    glVertex2f(flipX - (400 + (b/0.5) - flipX), 400 + (bb/0.5));
    glVertex2f(flipX - (430 + (b/0.5) - flipX), 380 + (bb/0.5));
    glVertex2f(flipX - (470 + (b/0.5) - flipX), 400 + (bb/0.5));
    glVertex2f(flipX - (430 + (b/0.5) - flipX), 420 + (bb/0.5));
    glEnd();

    // Tail of the fish (larger)
    glBegin(GL_POLYGON);
    glVertex2f(flipX - (470 + (b/0.5) - flipX), 400 + (bb/0.5));
    glVertex2f(flipX - (500 + (b/0.5) - flipX), 380 + (bb/0.5));
    glVertex2f(flipX - (500 + (b/0.5) - flipX), 420 + (bb/0.5));
    glEnd();

    // Eye of the fish (black)
    glColor3ub(0, 0, 0); // Black color for the eye
    glPointSize(5.0);
    glBegin(GL_POINTS);
    glVertex2f(flipX - (420 + (b/0.5) - flipX), 400 + (bb/0.5));
    glEnd();

    // White part of the fish
    glColor3ub(255, 255, 255); // White color

    // Add the white detail to the fish
    glBegin(GL_POLYGON);
    glVertex2f(flipX - (395 + (b/0.5) - flipX), 400 + (bb/0.5));
    glVertex2f(flipX - (400 + (b/0.5) - flipX), 398 + (bb/0.5));
    glVertex2f(flipX - (400 + (b/0.5) - flipX), 402 + (bb/0.5));
    glEnd();
}
