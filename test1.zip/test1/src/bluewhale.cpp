/*
 * bluewhale.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#include "bluewhale.h"

void BlueWhale() {
    // Body of the blue whale
    glBegin(GL_TRIANGLE_FAN);
    for (angle = 0; angle < 360; angle += 2) {
        glColor3ub(30, 50, 120); // Darker blue color for the whale body
        y = (sin(angle * pi / 319) * 70); // Increase the size of the body further
        x = angle;
        glVertex2f(x + 300 + w, y + 380 + ww); // Adjuat the whale'a poaition and aize
    }
    glColor3ub(70, 100, 170); // Slightly lighter blue for the center
    glVertex2f(x + 300 + w, y + 370 + ww);
    for (angle = 298; angle > 35; angle -= 2) {
        x = angle;
        y = -(sin(angle * pi / 319) * 40); // Make the tail longer
        glVertex2f(x + 300 + w, y + 370 + ww);
    }
    glVertex2f(320 + w, 370 + ww);
    glEnd();

    // Tail of the blue whale
    glColor3ub(30, 50, 120); // Darker blue color for the tail
    glBegin(GL_POLYGON);
    glVertex2f(598 + w, 390 + ww);
    glVertex2f(660 + w, 460 + ww);
    glColor3ub(20, 40, 100); // Slightly darker blue for the center of the tail
    glVertex2f(640 + w, 400 + ww);
    glVertex2f(660 + w, 340 + ww);
    glVertex2f(598 + w, 380 + ww);
    glEnd();

    glColor3ub(30, 50, 120); // Darker blue color for the fins

//eye
    glBegin(GL_TRIANGLE_FAN);
        for(angle=0; angle<360.0; angle+=.1){
            glColor3ub(0,0,0);
            y =(sin(angle*pi/180)*5);
            x =(cos(angle*pi/180)*5);
            glVertex2f(x+340+w,y+400+ww);
        }
        glEnd();

        glColor3f(1.0,1.0,1.0);
        glPointSize(4.0);
        glBegin(GL_POINTS);
        glVertex2f(340+w,400+ww+10);
        glEnd();


}
