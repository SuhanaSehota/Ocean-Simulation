/*
 * bluewhale.h
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#ifndef BLUEWHALE_H_
#define BLUEWHALE_H_

class bluewhale {
public:
	bluewhale();
	virtual ~bluewhale();
};

#endif /* BLUEWHALE_H_ */
