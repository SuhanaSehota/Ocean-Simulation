/*
 * fish.h
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#ifndef FISH_H_
#define FISH_H_

#include<stdio.h>
#include<stdlib.h>
#include <GL/glut.h>
#include<math.h>

class fish {
public:
	fish();
	virtual ~fish();
};

#endif /* FISH_H_ */
