/*
 * bubble.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#include "bubble.h"


void circleFunc(float yc,int d,int x1,int y1){
    for(angle=0; angle<360.0; angle+=.1)
{
        y =yc+(sin(angle*pi/180)*d);
        x =(cos(angle*pi/180)*d);
        glVertex2f(x+x1,y-y1);
}
}
float checkBubPos(float y,float c){
    if(y<500){
        return y+c;
    }
    else{
        return 0;
    }
}
void circle(int x){

    //to draw circles
    glBegin(GL_POINTS);
    circleFunc(y21,15,x+10,30);
    circleFunc(y31,5,x,60);
    circleFunc(y41,7,x+10,90);
    circleFunc(y51,12,x,120);
    circleFunc(y61,15,x+10,150);
    circleFunc(y71,5,x,180);
    circleFunc(y81,3,x+10,210);
    circleFunc(y81,15,x,240);
    circleFunc(y91,12,x+10,270);
    circleFunc(y10,10,x,300);
    circleFunc(y12,16,x+10,330);
    circleFunc(y13,15,x,360);
    circleFunc(y14,10,x+10,400);
glEnd();

y11 = checkBubPos(y11,2.0);
y21 = checkBubPos(y21,3.0);
y31 = checkBubPos(y31,4.5);
y41 = checkBubPos(y41,7.0);
y51 = checkBubPos(y51,6.5);
y61 = checkBubPos(y61,18.0);
y71 = checkBubPos(y71,17.5);
y81 = checkBubPos(y81,8.0);
y91 = checkBubPos(y91,7.5);
y10 = checkBubPos(y10,10.0);
y12 = checkBubPos(y12,11.0);
y14 = checkBubPos(y14,8.0);
y12 = checkBubPos(y12,9.0);
y13 = checkBubPos(y13,1.0);
glutPostRedisplay();

}
