/*
 * pb.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#include "pb.h"


void pbSmall(){

    glBegin(GL_TRIANGLE_FAN);
    for(angle=0; angle<360.0; angle+=.1){
        glColor3ub(46,47,47);
        y =(sin(angle*pi/180)*30);
        x =(cos(angle*pi/180)*50);
        glVertex2f(x+150,y-5);
    }
    glEnd();
}

void pb(){

    glBegin(GL_TRIANGLE_FAN);
    for(angle=0; angle<360.0; angle+=.1){
        glColor3ub( 128,128,128);
        y =(sin(angle*pi/180)*45);
        x =(cos(angle*pi/180)*75);
        glVertex2f(x+250,y-10);
    }
    glEnd();
}

 void pb1(){

    glBegin(GL_TRIANGLE_FAN);
    for(angle=0; angle<360.0; angle+=.1){
        glColor3ub( 128,128,128);
        y =(sin(angle*pi/180)*35);
        x =(cos(angle*pi/180)*65);
        glVertex2f(x+370,y-5);
    }
    glEnd();
}
 void pb2(){

    glBegin(GL_TRIANGLE_FAN);
    for(angle=0; angle<360.0; angle+=.1){
        glColor3ub(128, 128, 128);
        y =(sin(angle*pi/180)*40);
        x =(cos(angle*pi/180)*75);
        glVertex2f(x+610,y+10);
    }
    glEnd();
}
