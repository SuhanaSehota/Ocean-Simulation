/*
 * shark.h
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#ifndef SHARK_H_
#define SHARK_H_

class shark {
public:
	shark();
	virtual ~shark();
};

#endif /* SHARK_H_ */
