/*
 * pb.h
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#ifndef PB_H_
#define PB_H_

class pb {
public:
	pb();
	virtual ~pb();
};

#endif /* PB_H_ */
