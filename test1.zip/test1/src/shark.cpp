/*
 * shark.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#include "shark.h"


void Shark(){

    //For Shark Body
    glBegin(GL_TRIANGLE_FAN);
    for(angle=0; angle<320; angle+=2){
        glColor3ub(115,116,117);
        y =(sin(angle*pi/319)*30);
        x =angle;
        glVertex2f(x+280+s,y+285+ss);
    }
    glColor3ub(200,200,200);
    glVertex2f(x+280+s,y+265+ss);
    for(angle=298; angle>35; angle-=2){
        x =angle;
        y = -(sin(angle*pi/319)*20);
        glVertex2f(x+280+s,y+265+ss);
    }

    glVertex2f(300+s,265+ss);
    glEnd();
    glColor3ub(138,3,3);
    glBegin(GL_POLYGON);
    glVertex2f(302+s,263+ss);
    glVertex2f(330+s,276+ss);
    glVertex2f(297+s,268+ss);
    glEnd();

    //For Shark Tail
    glColor3ub(115,116,117);
    glBegin(GL_POLYGON);
    glVertex2f(598+s,285.6+ss);
    glVertex2f(640+s,330+ss);
    glColor3ub(rand()%40+190,rand()%40+190,rand()%40+190);
    glVertex2f(628+s,275+ss);
    glVertex2f(640+s,220+ss);
    glVertex2f(598+s,265+ss);
    glEnd();

    glColor3ub(100,106,107);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(410+s,313+ss);
    glColor3ub(150,150,150);
    glVertex2f(460+s,360+ss);
    glVertex2f(475+s,313+ss);
    glEnd();

    glColor3ub(115,116,117);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(420+s,260+ss);
    glVertex2f(450+s,210+ss);
    glColor3ub(rand()%40+190,rand()%40+190,rand()%40+190);
    glVertex2f(460+s,260+ss);
    glEnd();

    glColor3ub(115,116,117);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(555+s,297+ss);
    glVertex2f(580+s,305+ss);
    glVertex2f(580+s,290+ss);
    glEnd();

    glColor3ub(115,116,117);
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(555+s,257+ss);
    glVertex2f(580+s,247+ss);
    glColor3ub(rand()%40+190,rand()%40+190,rand()%40+190);
    glVertex2f(580+s,261+ss);
    glEnd();

    glBegin(GL_TRIANGLE_FAN);
    for(angle=0; angle<360.0; angle+=.1){
        glColor3ub(0,0,0);
        y =(sin(angle*pi/180)*5);
        x =(cos(angle*pi/180)*5);
        glVertex2f(x+332+s,y+287+ss);
    }
    glEnd();

    glColor3f(1.0,1.0,1.0);
    glPointSize(4.0);
    glBegin(GL_POINTS);
    glVertex2f(331.8+s,287+ss);
    glEnd();

}
