////============================================================================
//// Name        : test1.cpp
//// Author      : team
//// Version     :
//// Copyright   : Your copyright notice
//// Description : Hello World in C++, Ansi-style
////============================================================================
//
////#include<stdio.h>
////#include<stdlib.h>
////#include <GL/glut.h>
////#include<math.h>
////float  s=400,ss=140, a=0,b=0,aa=-70,bb=0,flag=0,flag3=0, flag4=0, w=0, ww=0;;
////float x=100,y=0,r=0.5,y11=0,y21=0,y31=0,y41=0,y51=0,y61=0,y71=0,y81=0,y91=0,y10=0,y12=0,y13=0,y14=0,x0=0,xo=0, angle=0.0, pi=3.142;
////int moving = 0;
////int temp =0;
////void create_menu(void);
////void menu(int);
////void mov(void);
////void BlueWhale(void);
////void Shark(void);
////
////GLuint backgroundTextureID;
////
////typedef struct Image {
////unsigned long sizeX;
////unsigned long sizeY;
////char *data;
////} Image;
////
////int ImageLoad(char *filename, Image *image) {
////FILE *file;
////unsigned long size; // size of the image in bytes.
////unsigned long i; // standard counter.
////unsigned short int planes; // number of planes in image (must be 1)
////unsigned short int bpp; // number of bits per pixel (must be 24)
////
////char temp; // temporary color storage for bgr-rgb conversion.
////
////// make sure the file is there.
////if ((file = fopen(filename, "rb")) == NULL) {
////printf("File Not Found : %s\n", filename);
////return 0;
////}
////
////// seek through the bmp header, up to the width/height:
////fseek(file, 18, SEEK_CUR);
////
////// read the width
////if ((i = fread(&image->sizeX, 4, 1, file)) != 1) {
////printf("Error reading width from %s.\n", filename);
////return 0;
////}
////
////// read the height
////if ((i = fread(&image->sizeY, 4, 1, file)) != 1) {
////printf("Error reading height from %s.\n", filename);
////return 0;
////}
////
////size = image->sizeX * image->sizeY * 3;
////
////if ((fread(&planes, 2, 1, file)) != 1) {
////printf("Error reading planes from %s.\n", filename);
////return 0;
////}
////
////if (planes != 1) {
////printf("Planes from %s is not 1: %u\n", filename, planes);
////return 0;
////}
////
////// read the bitsperpixel
////if ((i = fread(&bpp, 2, 1, file)) != 1) {
////printf("Error reading bpp from %s.\n", filename);
////return 0;
////}
////
////if (bpp != 24) {
////printf("Bpp from %s is not 24: %u\n", filename, bpp);
////return 0;
////}
////
////// seek past the rest of the bitmap header.
////fseek(file, 24, SEEK_CUR);
////
////image->data = (char *) malloc(size);
////if (image->data == NULL) {
////printf("Error allocating memory for color-corrected image data");
////return 0;
////}
////
////if ((i = fread(image->data, size, 1, file)) != 1) {
////printf("Error reading image data from %s.\n", filename);
////return 0;
////}
////
////for (i = 0; i < size; i += 3) { // reverse all of the colors. (bgr -> rgb)
////temp = image->data[i];
////image->data[i] = image->data[i + 2];
////image->data[i + 2] = temp;
////}
////return 1;
////}
////
////Image* loadTexture(char *filename) {
////Image *image = (Image *) malloc(sizeof(Image));
////if (image == NULL) {
////printf("Error allocating space for image");
////exit(0);
////}
////if (!ImageLoad(filename, image)) {
////exit(1);
////}
////return image;
////}
////
////void drawstring(float x,float y,float z,char *string, int f)
////{
////    char *c;
////    glRasterPos3f(x,y,z);
////    for(c=string;*c!='\0';c++){
////        if(f==0)
////            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,*c);
////        else
////            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,*c);
////    }
////}
////
////void init()
////{
////glClearColor(0.7, 0.9, 1.0, 0.0);
////
////glMatrixMode(GL_PROJECTION);
////glLoadIdentity();
////gluOrtho2D(0,500,0,500);
////
////Image* backgroundImage = loadTexture("background.bmp"); // Ensure this image exists
////glGenTextures(1, &backgroundTextureID);
////glBindTexture(GL_TEXTURE_2D, backgroundTextureID);
////glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, backgroundImage->sizeX, backgroundImage->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, backgroundImage->data);
////glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
////glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
////
////    // Free the image memory
////free(backgroundImage->data);
////free(backgroundImage);
////}
////void screen()
////{
////    glClear(GL_COLOR_BUFFER_BIT);
////glColor3f(0.0,0.0,0.0);
////drawstring(290,425,0.0,"Wilfrid Laurier University, CP411 Computer Graphics",1);
////glColor3f(0.0,0.0,0.0);
////drawstring(450,385,0.0,"Final Project",1);
////glColor3f(0.0,0.0,0.0);
////drawstring(300,350,0.0,"Suhana Sehota, Nora Chamseddin, Andrew Yoon",1);
////glColor3f(0.0,0.0,0.0);
////drawstring(440,300,0.0,"OCEAN SIMULATION",1);
////glColor3f(0.0,0.0,0.0);
////glColor3f(0.0,0.0,0.0);
////drawstring(420,95,0.0,"December 4th, 2023",0);
////drawstring(400,65,0.0,"Press 'P' to start the game",0);
////
////glFlush();
//// glutSwapBuffers();
////}
////void reshape(GLint w, GLint h)
////{
////glViewport(0, 0, w, h);
////glMatrixMode(GL_PROJECTION);
////glLoadIdentity();
////if(h>w)
////gluOrtho2D(0, 500, ((float)h/(float)w)*(0), ((float)h/(float)w)*500);
////else
////        gluOrtho2D(((float)w/(float)h)*(0), ((float)w/(float)h)*(520), 0, 500);
////glMatrixMode(GL_MODELVIEW);
////glutPostRedisplay();
////}
////void fish1()
////{
////    // Body of the fish, changed color to blue
////    glColor3f(0.0, 0.0, 1.0);
////    glBegin(GL_POLYGON);
////    glVertex2f(270+a,350+aa);
////    glVertex2f(300+a,325+aa);
////    glVertex2f(370+a,350+aa);
////    glVertex2f(300+a,375+aa);
////    glEnd();
////
////    // Tail, changed to a consistent color
////    glBegin(GL_POLYGON);
////    glColor3f(0.8, 0.3, 0.2);
////    glVertex2f(360+a,350+aa);
////    glVertex2f(405+a,370+aa);
////    glVertex2f(395+a,350+aa);
////    glVertex2f(405+a,327+aa);
////    glEnd();
////
////    // Top fin, changed shape and color
////    glBegin(GL_TRIANGLES);
////    glColor3f(0.8, 0.3, 0.2);
////    glVertex2f(302+a,373+aa);
////    glVertex2f(340+a,420+aa); // Extended the fin
////    glVertex2f(320+a,360+aa);
////    glEnd();
////
////    // Bottom fin, changed shape and color
////    glBegin(GL_TRIANGLES);
////    glColor3f(0.8, 0.3, 0.2);
////    glVertex2f(302+a,328+aa);
////    glVertex2f(340+a,290+aa); // Extended the fin
////    glVertex2f(320+a,340+aa);
////    glEnd();
////
////    // Eye of the fish
////    glColor3f(0.0, 0.0, 0.0);
////    glPointSize(4.0);
////    glBegin(GL_POINTS);
////    glVertex2f(280+a,355+aa);
////    glEnd();
////}
////
////void fish2()
////{
////glColor3f(1.0,0.0,0.0);
////  glBegin(GL_POLYGON);
////     glVertex2f(70-b,145-bb);
////  glColor3ub(rand()%500, rand()%500,0);
////   glVertex2f(20-b,120-bb);
////    glVertex2f(30-b,145-bb);
////   glVertex2f(20-b,170-bb);
////
////
////  glEnd();
////  glColor3f(1.0,0.0,0.0);
////    glBegin(GL_POLYGON);
////   glVertex2f(65-b,145-bb);
////
////   glVertex2f(125-b,170-bb);
////
////   glVertex2f(165-b,145-bb);
////   glVertex2f(125-b,120-bb);
////  glEnd();
////
////  glBegin(GL_TRIANGLES);
////  glColor3ub(rand()%500, rand()%500,0);
////    glVertex2f(126-b,168-bb);
////   glColor3f(1.0,0.0,0.0);
////   glVertex2f(110-b,155-bb);
////    glVertex2f(85-b,195-bb);
//// glEnd();
//// glBegin(GL_TRIANGLES);
////  glColor3ub(rand()%500, rand()%500,0);
////    glVertex2f(126-b,122-bb);
////   glColor3f(1.0,0.0,0.0);
////glVertex2f(110-b,136-bb);
////glVertex2f(85-b,95-bb);
////  glEnd();
//// glColor3f(0.0,0.0,0.0);
////  glPointSize(4.0);
////  glBegin(GL_POINTS);
////  glVertex2f(150-b,149-bb);
////  glEnd();
////
////}
////
////void goldfish() {
////    glColor3ub(255, 165, 0); // Goldfish color (orange)
////
////    // Body of the goldfish
////    glBegin(GL_POLYGON);
////    glVertex2f(200 + (a/0.5), 200 + (aa/0.5));
////    glVertex2f(220 + (a/0.5), 190 + (aa/0.5));
////    glVertex2f(240 + (a/0.5), 200 + (aa/0.5));
////    glVertex2f(220 + (a/0.5), 210 + (aa/0.5));
////    glEnd();
////
////    // Tail of the goldfish
////    glBegin(GL_POLYGON);
////    glVertex2f(240 + (a/0.5), 200 + (aa/0.5));
////    glVertex2f(260 + (a/0.5), 190 + (aa/0.5));
////    glVertex2f(260 + (a/0.5), 210 + (aa/0.5));
////    glEnd();
////
////    // Eye of the goldfish
////    glColor3ub(0, 0, 0); // Black color for the eye
////    glPointSize(3.0);
////    glBegin(GL_POINTS);
////    glVertex2f(210 + (a/0.5), 200 + (aa/0.5));
////    glEnd();
////}
////
////void anotherFish() {
////    // Horizontal flip point (you can adjust this as needed)
////    float flipX = 450;
////
////    // Pink color for the fish
////    glColor3ub(255, 192, 203); // Pink color
////
////    // Body of the fish (larger)
////    glBegin(GL_POLYGON);
////    glVertex2f(flipX - (400 + (b/0.5) - flipX), 400 + (bb/0.5));
////    glVertex2f(flipX - (430 + (b/0.5) - flipX), 380 + (bb/0.5));
////    glVertex2f(flipX - (470 + (b/0.5) - flipX), 400 + (bb/0.5));
////    glVertex2f(flipX - (430 + (b/0.5) - flipX), 420 + (bb/0.5));
////    glEnd();
////
////    // Tail of the fish (larger)
////    glBegin(GL_POLYGON);
////    glVertex2f(flipX - (470 + (b/0.5) - flipX), 400 + (bb/0.5));
////    glVertex2f(flipX - (500 + (b/0.5) - flipX), 380 + (bb/0.5));
////    glVertex2f(flipX - (500 + (b/0.5) - flipX), 420 + (bb/0.5));
////    glEnd();
////
////    // Eye of the fish (black)
////    glColor3ub(0, 0, 0); // Black color for the eye
////    glPointSize(5.0);
////    glBegin(GL_POINTS);
////    glVertex2f(flipX - (420 + (b/0.5) - flipX), 400 + (bb/0.5));
////    glEnd();
////
////    // White part of the fish
////    glColor3ub(255, 255, 255); // White color
////
////    // Add the white detail to the fish
////    glBegin(GL_POLYGON);
////    glVertex2f(flipX - (395 + (b/0.5) - flipX), 400 + (bb/0.5));
////    glVertex2f(flipX - (400 + (b/0.5) - flipX), 398 + (bb/0.5));
////    glVertex2f(flipX - (400 + (b/0.5) - flipX), 402 + (bb/0.5));
////    glEnd();
////}
//
////
////
////void pbSmall(){
////
////    glBegin(GL_TRIANGLE_FAN);
////    for(angle=0; angle<360.0; angle+=.1){
////        glColor3ub(46,47,47);
////        y =(sin(angle*pi/180)*30);
////        x =(cos(angle*pi/180)*50);
////        glVertex2f(x+150,y-5);
////    }
////    glEnd();
////}
////
////void pb(){
////
////    glBegin(GL_TRIANGLE_FAN);
////    for(angle=0; angle<360.0; angle+=.1){
////        glColor3ub( 128,128,128);
////        y =(sin(angle*pi/180)*45);
////        x =(cos(angle*pi/180)*75);
////        glVertex2f(x+250,y-10);
////    }
////    glEnd();
////}
////
//// void pb1(){
////
////    glBegin(GL_TRIANGLE_FAN);
////    for(angle=0; angle<360.0; angle+=.1){
////        glColor3ub( 128,128,128);
////        y =(sin(angle*pi/180)*35);
////        x =(cos(angle*pi/180)*65);
////        glVertex2f(x+370,y-5);
////    }
////    glEnd();
////}
//// void pb2(){
////
////    glBegin(GL_TRIANGLE_FAN);
////    for(angle=0; angle<360.0; angle+=.1){
////        glColor3ub(128, 128, 128);
////        y =(sin(angle*pi/180)*40);
////        x =(cos(angle*pi/180)*75);
////        glVertex2f(x+610,y+10);
////    }
////    glEnd();
////}
////
////void circleFunc(float yc,int d,int x1,int y1){
////    for(angle=0; angle<360.0; angle+=.1)
////{
////        y =yc+(sin(angle*pi/180)*d);
////        x =(cos(angle*pi/180)*d);
////        glVertex2f(x+x1,y-y1);
////}
////}
////float checkBubPos(float y,float c){
////    if(y<500){
////        return y+c;
////    }
////    else{
////        return 0;
////    }
////}
////void circle(int x){
////
////    //to draw circles
////    glBegin(GL_POINTS);
////    circleFunc(y21,15,x+10,30);
////    circleFunc(y31,5,x,60);
////    circleFunc(y41,7,x+10,90);
////    circleFunc(y51,12,x,120);
////    circleFunc(y61,15,x+10,150);
////    circleFunc(y71,5,x,180);
////    circleFunc(y81,3,x+10,210);
////    circleFunc(y81,15,x,240);
////    circleFunc(y91,12,x+10,270);
////    circleFunc(y10,10,x,300);
////    circleFunc(y12,16,x+10,330);
////    circleFunc(y13,15,x,360);
////    circleFunc(y14,10,x+10,400);
////glEnd();
////
////y11 = checkBubPos(y11,2.0);
////y21 = checkBubPos(y21,3.0);
////y31 = checkBubPos(y31,4.5);
////y41 = checkBubPos(y41,7.0);
////y51 = checkBubPos(y51,6.5);
////y61 = checkBubPos(y61,18.0);
////y71 = checkBubPos(y71,17.5);
////y81 = checkBubPos(y81,8.0);
////y91 = checkBubPos(y91,7.5);
////y10 = checkBubPos(y10,10.0);
////y12 = checkBubPos(y12,11.0);
////y14 = checkBubPos(y14,8.0);
////y12 = checkBubPos(y12,9.0);
////y13 = checkBubPos(y13,1.0);
////glutPostRedisplay();
////
////}
////
////void plant3L(int x1, int x2, int m) {
////    int dis = x2 - x1;
////    dis = dis / 3;
////    glColor3ub(40, 170, 5);
////    glBegin(GL_POLYGON);
////    glVertex2f(x1, 14);  // Adjust the y-coordinate
////    glVertex2f(x1 - 10, m - 10 + 14);  // Adjust the y-coordinate
////    glColor3f(0.0, 0.5, 0.0);
////    glVertex2f(x1 + dis, 15 + 14);  // Adjust the y-coordinate
////    glVertex2f(x1 + ((x2 - x1) / 2), m + 50);  // Adjust the y-coordinate
////    glVertex2f(x2 - dis, 15 + 14);  // Adjust the y-coordinate
////    glVertex2f(x2 + 12, m + 10 + 14);  // Adjust the y-coordinate
////    glVertex2f(x2, 14);  // Adjust the y-coordinate
////    glEnd();
////}
////
////
////
////void plant2L(int x1, int x2, int h1, int h2){
////
////    glColor3ub( 60,170,15);
////    glBegin(GL_POLYGON);
////    glVertex2f(x1,30);
////    glVertex2f(x1-20,h1+30);
////    glColor3f(0.0,0.3,0.0);
////    glVertex2f(x2,30);
////    glVertex2f(x1+15,h2+30);
////    glEnd();
////}
////
////
////void plant()
////{
////    plant2L(50,40,40,60);
////    plant2L(95,85,50,60);
////    plant2L(120,110,45,65);
////    plant2L(70,60,60,40);
////    plant2L(140,130,43,60);
////    plant2L(950,940,40,50);
////    plant2L(870,860,50,60);
////    plant2L(470,460,40,50);
////    plant2L(490,480,55,65);
////    plant2L(520,510,40,50);
////    plant2L(540,530,50,60);
////    plant2L(700,690,40,50);
////    plant2L(730,720,55,65);
////    plant2L(795,785,40,50);
////
////    plant3L(10,20,60);
////    plant3L(160,170,50);
////    plant3L(310,320,70);
////    plant3L(435,445,60);
////    plant3L(750,760, 55);
////    plant3L(820,830,80);
////    plant3L(900,910, 55);
////}
////
////void drawSand() {
////    glColor3f(0.8, 0.8, 0.6);  // Sand color
////    glBegin(GL_QUADS);
////    glVertex2f(0, 0);
////    glVertex2f(1100, 0);
////    glVertex2f(1100, 50);  // Adjust the height of the sand as needed
////    glVertex2f(0, 50);
////    glEnd();
////}
//
////
////void display(void){
////
////    glClear(GL_COLOR_BUFFER_BIT);
////
////
////    // Draw the background
////    glEnable(GL_TEXTURE_2D);
////    glBindTexture(GL_TEXTURE_2D, backgroundTextureID);
////    glBegin(GL_QUADS);
////    glTexCoord2f(0.0, 1.0); glVertex2f(0.0, glutGet(GLUT_WINDOW_HEIGHT));
////    glTexCoord2f(1.0, 1.0); glVertex2f(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
////    glTexCoord2f(1.0, 0.0); glVertex2f(glutGet(GLUT_WINDOW_WIDTH), 0.0);
////    glTexCoord2f(0.0, 0.0); glVertex2f(0.0, 0.0);
////    glEnd();
////    glDisable(GL_TEXTURE_2D);
////
////    if(moving==1){
////        mov();
////    }
////    drawSand();
////    plant();
////    pb1();
////    pb2();
////    pb();
////    fish1();
////    BlueWhale();
////
////    fish2();
////    anotherFish();
////    Shark();
////
////
////    goldfish();
////
////
////
////
////    glColor3f(1.0,1.0,1.0);
////    glPointSize(2.0);
////    circle(30);
////    circle(930);
////
////
////    if(flag3==0){
////        screen();
////    }
////
////    glFlush();
////    glutSwapBuffers();
////}
////
////void mov(void){
////    // Movement logic for 'a' (shark) and 'aa' (whale) - this part remains unchanged
////    if(a >= -500)
////        a = a - 7;
////    else
////        a = 700;
////
////    if(a < -500){
////        aa = aa - 100;
////    }
////
////    if(aa < -251){
////        aa = 100;
////    }
////
////    if(b >= -950)
////        b = b - 8.0;
////    else
////        b = 1000;
////
////    if(b > 1000){
////        // Change the direction of bb by decrementing it instead of incrementing
////        bb = bb -150;
////    }
////
////    if(bb < -251){ // Adjust the condition for the lower limit
////        bb = 50;
////    }
////
////    // Movement logic for 's' (shark's y-axis) and 'ss' (whale's y-axis)
////    if(s >= -700)
////        s = s - 9;
////    else
////        s = 700;
////
////    if(s < -700){
////        ss = ss - 250;
////    }
////
////    if(ss < -251){
////        ss = 50;
////    }
////    if(w >= -700)
////    w = w - 2;
////    else
////    w = 700;
////
////
////    if(w < -700){
////    ww = ww - 250;
////    }
////
////    if(ww < -251){
////    ww = 50;
////    }
////}
////
////void create_menu(void){
////
////     glutCreateMenu(menu);
////     glutAttachMenu(GLUT_LEFT_BUTTON);
////     glutAttachMenu(GLUT_RIGHT_BUTTON);
////     glutAddMenuEntry("move", 1);
////     glutAddMenuEntry("stop", 2);
////     glutAddMenuEntry("back", 3);
////     glutAddMenuEntry("quit", 4);
////
////}
////
////void menu(int val){
////    switch (val) {
////        case 1:
////            if(flag4==1 && moving ==0)
////                moving = 1;
////            break;
////        case 2:
////            glutIdleFunc(NULL);
////            glutDisplayFunc(display);
////            moving = 0;
////            break;
////        case 3:
////            moving = 0;
////            flag3=0;
////            flag4=0;
////            screen();
////            break;
////        case 4: exit(0);
////            break;
////
////    }
////}
////
////void speed()
////{
////a=a-9.0;
////s=s-10;
////b=b+10;
////}
////
////void slow()
////{
////a=a-0.0001;
////}
////
////void key(unsigned char k,int x,int y)
////{
////if(k=='i')
////        glutIdleFunc(speed);
////
////if(k=='d'){
////        glutIdleFunc(slow);
////}
////
////if(k=='p'){
////        flag3=1;
////        flag4=1;
////}
////
////}
////
//
//void drawFrog(){
//
//    glPushMatrix();
//    glTranslatef(600,55,0);
//    glRotatef(50, 0, 0, 1);
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=0; angle<360.0; angle+=.1){
//        glColor3ub(46,127,7);
//        y =(sin(angle*pi/180)*15);
//        x =(cos(angle*pi/180)*7);
//        glVertex2f(x,y);
//    }
//    glEnd();
//    glPopMatrix();
//
//    glPushMatrix();
//    glTranslatef(630,55,0);
//    glRotatef(-50, 0, 0, 1);
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=0; angle<360.0; angle+=.1){
//        glColor3ub(46,127,7);
//        y =(sin(angle*pi/180)*15);
//        x =(cos(angle*pi/180)*7);
//        glVertex2f(x,y);
//    }
//    glEnd();
//    glPopMatrix();
//
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=0; angle<360.0; angle+=.1){
//        glColor3ub(46,150,7);
//        y =(sin(angle*pi/180)*21);
//        x =(cos(angle*pi/180)*13);
//        glVertex2f(x+615,y+65);
//    }
//    glEnd();
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=0; angle<360.0; angle+=.1){
//        glColor3ub(46,130,7);
//        y =(sin(angle*pi/180)*10);
//        x =(cos(angle*pi/180)*17);
//        glVertex2f(x+615,y+85);
//    }
//    glEnd();
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=0; angle<360.0; angle+=.1){
//        glColor3ub(255,255,255);
//        y =(sin(angle*pi/180)*7);
//        x =(cos(angle*pi/180)*5);
//        glVertex2f(x+605,y+92);
//    }
//    glEnd();
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=0; angle<360.0; angle+=.1){
//        glColor3ub(255,255,255);
//        y =(sin(angle*pi/180)*7);
//        x =(cos(angle*pi/180)*5);
//        glVertex2f(x+625,y+92);
//    }
//    glEnd();
//
//    glBegin(GL_TRIANGLE_FAN);
//    for(angle=180; angle<360.0; angle+=.1){
//        glColor3ub(255,255,255);
//        y =(sin(angle*pi/180)*7);
//        x =(cos(angle*pi/180)*7);
//        glVertex2f(x+615,y+82);
//    }
//    glEnd();
//
//    glColor3f(0.0,0.0,0.0);
//    glPointSize(6.0);
//    glBegin(GL_POINTS);
//    glVertex2f(605,92);
//    glVertex2f(625,92);
//    glEnd();
//
//    glColor3ub(46,115,7);
//    glBegin(GL_POLYGON);
//    glVertex2f(605,70);
//    glVertex2f(600,42);
//    glVertex2f(604,42);
//    glVertex2f(611,70);
//    glEnd();
//
//    glColor3ub(46,115,7);
//    glBegin(GL_POLYGON);
//    glVertex2f(620,70);
//    glVertex2f(627,42);
//    glVertex2f(631,42);
//    glVertex2f(626,70);
//    glEnd();
//
//
//}
//
////void drawSineWave(){
////    glPointSize(8.0);
////    glBegin(GL_POINTS);
////    for(angle=0; angle<500.0; angle=angle+0.9){
////        glColor3ub(46,110,7);
////        x =(sin(angle*pi/90)*15);
////        y = angle;
////        glVertex2f(x+960,y);
////    }
////    glEnd();
////    drawLeafLeft(960,80);
////    drawLeafLeft(969,210);
////    drawLeafLeft(945,330);
////    drawLeafLeft(957,460);
////    drawLeafRight(945,140);
////    drawLeafRight(957,280);
////    drawLeafRight(971,410);
////}
//void drawLeafLeft(int x, int y){
//
//    glLineWidth(5);
//    glColor3ub( 60,120,15);
//    glBegin(GL_LINES);
//    glVertex2f(x,y);
//    glVertex2f(x-10,y);
//    glEnd();
//
//    glColor3ub( 60,170,15);
//    glBegin(GL_POLYGON);
//    glVertex2f(x-10,y);
//    glVertex2f(x-17,y+18);
//    glVertex2f(x-50,y+13);
//    glColor3f(0.1,0.5,0.0);
//    glVertex2f(x-70,y);
//    glVertex2f(x-50,y-13);
//    glVertex2f(x-17,y-18);
//    glEnd();
//
//}
//void drawLeafRight(int x, int y){
//
//    glLineWidth(5);
//    glColor3ub( 60,120,15);
//    glBegin(GL_LINES);
//    glVertex2f(x,y);
//    glVertex2f(x+10,y);
//    glEnd();
//
//    glColor3ub( 60,170,15);
//    glBegin(GL_POLYGON);
//    glVertex2f(x+10,y);
//    glVertex2f(x+17,y+18);
//    glVertex2f(x+50,y+13);
//    glColor3f(0.1,0.5,0.0);
//    glVertex2f(x+70,y);
//    glVertex2f(x+50,y-13);
//    glVertex2f(x+17,y-18);
//    glEnd();
//
////}
////void Shark(){
////
////    //For Shark Body
////    glBegin(GL_TRIANGLE_FAN);
////    for(angle=0; angle<320; angle+=2){
////        glColor3ub(115,116,117);
////        y =(sin(angle*pi/319)*30);
////        x =angle;
////        glVertex2f(x+280+s,y+285+ss);
////    }
////    glColor3ub(200,200,200);
////    glVertex2f(x+280+s,y+265+ss);
////    for(angle=298; angle>35; angle-=2){
////        x =angle;
////        y = -(sin(angle*pi/319)*20);
////        glVertex2f(x+280+s,y+265+ss);
////    }
////
////    glVertex2f(300+s,265+ss);
////    glEnd();
////    glColor3ub(138,3,3);
////    glBegin(GL_POLYGON);
////    glVertex2f(302+s,263+ss);
////    glVertex2f(330+s,276+ss);
////    glVertex2f(297+s,268+ss);
////    glEnd();
////
////    //For Shark Tail
////    glColor3ub(115,116,117);
////    glBegin(GL_POLYGON);
////    glVertex2f(598+s,285.6+ss);
////    glVertex2f(640+s,330+ss);
////    glColor3ub(rand()%40+190,rand()%40+190,rand()%40+190);
////    glVertex2f(628+s,275+ss);
////    glVertex2f(640+s,220+ss);
////    glVertex2f(598+s,265+ss);
////    glEnd();
////
////    glColor3ub(100,106,107);
////    glBegin(GL_TRIANGLE_FAN);
////    glVertex2f(410+s,313+ss);
////    glColor3ub(150,150,150);
////    glVertex2f(460+s,360+ss);
////    glVertex2f(475+s,313+ss);
////    glEnd();
////
////    glColor3ub(115,116,117);
////    glBegin(GL_TRIANGLE_FAN);
////    glVertex2f(420+s,260+ss);
////    glVertex2f(450+s,210+ss);
////    glColor3ub(rand()%40+190,rand()%40+190,rand()%40+190);
////    glVertex2f(460+s,260+ss);
////    glEnd();
////
////    glColor3ub(115,116,117);
////    glBegin(GL_TRIANGLE_FAN);
////    glVertex2f(555+s,297+ss);
////    glVertex2f(580+s,305+ss);
////    glVertex2f(580+s,290+ss);
////    glEnd();
////
////    glColor3ub(115,116,117);
////    glBegin(GL_TRIANGLE_FAN);
////    glVertex2f(555+s,257+ss);
////    glVertex2f(580+s,247+ss);
////    glColor3ub(rand()%40+190,rand()%40+190,rand()%40+190);
////    glVertex2f(580+s,261+ss);
////    glEnd();
////
////    glBegin(GL_TRIANGLE_FAN);
////    for(angle=0; angle<360.0; angle+=.1){
////        glColor3ub(0,0,0);
////        y =(sin(angle*pi/180)*5);
////        x =(cos(angle*pi/180)*5);
////        glVertex2f(x+332+s,y+287+ss);
////    }
////    glEnd();
////
////    glColor3f(1.0,1.0,1.0);
////    glPointSize(4.0);
////    glBegin(GL_POINTS);
////    glVertex2f(331.8+s,287+ss);
////    glEnd();
////
////}
//
////void BlueWhale() {
////    // Body of the blue whale
////    glBegin(GL_TRIANGLE_FAN);
////    for (angle = 0; angle < 360; angle += 2) {
////        glColor3ub(30, 50, 120); // Darker blue color for the whale body
////        y = (sin(angle * pi / 319) * 70); // Increase the size of the body further
////        x = angle;
////        glVertex2f(x + 300 + w, y + 380 + ww); // Adjuat the whale'a poaition and aize
////    }
////    glColor3ub(70, 100, 170); // Slightly lighter blue for the center
////    glVertex2f(x + 300 + w, y + 370 + ww);
////    for (angle = 298; angle > 35; angle -= 2) {
////        x = angle;
////        y = -(sin(angle * pi / 319) * 40); // Make the tail longer
////        glVertex2f(x + 300 + w, y + 370 + ww);
////    }
////    glVertex2f(320 + w, 370 + ww);
////    glEnd();
////
////    // Tail of the blue whale
////    glColor3ub(30, 50, 120); // Darker blue color for the tail
////    glBegin(GL_POLYGON);
////    glVertex2f(598 + w, 390 + ww);
////    glVertex2f(660 + w, 460 + ww);
////    glColor3ub(20, 40, 100); // Slightly darker blue for the center of the tail
////    glVertex2f(640 + w, 400 + ww);
////    glVertex2f(660 + w, 340 + ww);
////    glVertex2f(598 + w, 380 + ww);
////    glEnd();
////
////    glColor3ub(30, 50, 120); // Darker blue color for the fins
////
//////eye
////    glBegin(GL_TRIANGLE_FAN);
////        for(angle=0; angle<360.0; angle+=.1){
////            glColor3ub(0,0,0);
////            y =(sin(angle*pi/180)*5);
////            x =(cos(angle*pi/180)*5);
////            glVertex2f(x+340+w,y+400+ww);
////        }
////        glEnd();
////
////        glColor3f(1.0,1.0,1.0);
////        glPointSize(4.0);
////        glBegin(GL_POINTS);
////        glVertex2f(340+w,400+ww+10);
////        glEnd();
////
////
////}
////
////void helloF(){
////    glClear(GL_COLOR_BUFFER_BIT);
////    pb1();
////    pb2();
////    pb();
////    plant();
////    Shark();
////}
////int main(int argc,char **argv)
////{
////glutInit(&argc,argv);
////glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
////    glutInitWindowPosition(0,0);
////    glutInitWindowSize(1200,600);
////    glutCreateWindow("Andrew");
////    init();
////    glutReshapeFunc(reshape);
////    glutKeyboardFunc(key);
////    //glutDisplayFunc(helloF);
////    glutDisplayFunc(display);
////    create_menu();
////    glutMainLoop();
////}
//
////seperate fish from whale
////change rocks
////add a clam on the other rock
////change fish shape
////texture the ocean
////add moving seaweed
////replace vine to something else
