/*
 * main.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#include "main.h"

#include<stdio.h>
#include<stdlib.h>
#include <GL/glut.h>
#include<math.h>
float  s=400,ss=140, a=0,b=0,aa=-70,bb=0,flag=0,flag3=0, flag4=0, w=0, ww=0;;
float x=100,y=0,r=0.5,y11=0,y21=0,y31=0,y41=0,y51=0,y61=0,y71=0,y81=0,y91=0,y10=0,y12=0,y13=0,y14=0,x0=0,xo=0, angle=0.0, pi=3.142;
int moving = 0;
int temp =0;
void create_menu(void);
void menu(int);
void mov(void);
void BlueWhale(void);
void Shark(void);

GLuint backgroundTextureID;

typedef struct Image {
unsigned long sizeX;
unsigned long sizeY;
char *data;
} Image;

int ImageLoad(char *filename, Image *image) {
FILE *file;
unsigned long size; // size of the image in bytes.
unsigned long i; // standard counter.
unsigned short int planes; // number of planes in image (must be 1)
unsigned short int bpp; // number of bits per pixel (must be 24)

char temp; // temporary color storage for bgr-rgb conversion.

// make sure the file is there.
if ((file = fopen(filename, "rb")) == NULL) {
printf("File Not Found : %s\n", filename);
return 0;
}

// seek through the bmp header, up to the width/height:
fseek(file, 18, SEEK_CUR);

// read the width
if ((i = fread(&image->sizeX, 4, 1, file)) != 1) {
printf("Error reading width from %s.\n", filename);
return 0;
}

// read the height
if ((i = fread(&image->sizeY, 4, 1, file)) != 1) {
printf("Error reading height from %s.\n", filename);
return 0;
}

size = image->sizeX * image->sizeY * 3;

if ((fread(&planes, 2, 1, file)) != 1) {
printf("Error reading planes from %s.\n", filename);
return 0;
}

if (planes != 1) {
printf("Planes from %s is not 1: %u\n", filename, planes);
return 0;
}

// read the bitsperpixel
if ((i = fread(&bpp, 2, 1, file)) != 1) {
printf("Error reading bpp from %s.\n", filename);
return 0;
}

if (bpp != 24) {
printf("Bpp from %s is not 24: %u\n", filename, bpp);
return 0;
}

// seek past the rest of the bitmap header.
fseek(file, 24, SEEK_CUR);

image->data = (char *) malloc(size);
if (image->data == NULL) {
printf("Error allocating memory for color-corrected image data");
return 0;
}

if ((i = fread(image->data, size, 1, file)) != 1) {
printf("Error reading image data from %s.\n", filename);
return 0;
}

for (i = 0; i < size; i += 3) { // reverse all of the colors. (bgr -> rgb)
temp = image->data[i];
image->data[i] = image->data[i + 2];
image->data[i + 2] = temp;
}
return 1;
}

Image* loadTexture(char *filename) {
Image *image = (Image *) malloc(sizeof(Image));
if (image == NULL) {
printf("Error allocating space for image");
exit(0);
}
if (!ImageLoad(filename, image)) {
exit(1);
}
return image;
}

void drawstring(float x,float y,float z,char *string, int f)
{
    char *c;
    glRasterPos3f(x,y,z);
    for(c=string;*c!='\0';c++){
        if(f==0)
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,*c);
        else
            glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,*c);
    }
}

void init()
{
glClearColor(0.7, 0.9, 1.0, 0.0);

glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0,500,0,500);

Image* backgroundImage = loadTexture("background.bmp"); // Ensure this image exists
glGenTextures(1, &backgroundTextureID);
glBindTexture(GL_TEXTURE_2D, backgroundTextureID);
glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, backgroundImage->sizeX, backgroundImage->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, backgroundImage->data);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Free the image memory
free(backgroundImage->data);
free(backgroundImage);
}
void screen()
{
    glClear(GL_COLOR_BUFFER_BIT);
glColor3f(0.0,0.0,0.0);
drawstring(290,425,0.0,"Wilfrid Laurier University, CP411 Computer Graphics",1);
glColor3f(0.0,0.0,0.0);
drawstring(450,385,0.0,"Final Project",1);
glColor3f(0.0,0.0,0.0);
drawstring(300,350,0.0,"Suhana Sehota, Nora Chamseddin, Andrew Yoon",1);
glColor3f(0.0,0.0,0.0);
drawstring(440,300,0.0,"OCEAN SIMULATION",1);
glColor3f(0.0,0.0,0.0);
glColor3f(0.0,0.0,0.0);
drawstring(420,95,0.0,"December 4th, 2023",0);
drawstring(400,65,0.0,"Press 'P' to start the game",0);

glFlush();
 glutSwapBuffers();
}
void reshape(GLint w, GLint h)
{
glViewport(0, 0, w, h);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
if(h>w)
gluOrtho2D(0, 500, ((float)h/(float)w)*(0), ((float)h/(float)w)*500);
else
        gluOrtho2D(((float)w/(float)h)*(0), ((float)w/(float)h)*(520), 0, 500);
glMatrixMode(GL_MODELVIEW);
glutPostRedisplay();
}


void display(void){

    glClear(GL_COLOR_BUFFER_BIT);


    // Draw the background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, backgroundTextureID);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 1.0); glVertex2f(0.0, glutGet(GLUT_WINDOW_HEIGHT));
    glTexCoord2f(1.0, 1.0); glVertex2f(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
    glTexCoord2f(1.0, 0.0); glVertex2f(glutGet(GLUT_WINDOW_WIDTH), 0.0);
    glTexCoord2f(0.0, 0.0); glVertex2f(0.0, 0.0);
    glEnd();
    glDisable(GL_TEXTURE_2D);

    if(moving==1){
        mov();
    }
    drawSand();
    plant();
    pb1();
    pb2();
    pb();
    fish1();
    BlueWhale();

    fish2();
    anotherFish();
    Shark();


    goldfish();




    glColor3f(1.0,1.0,1.0);
    glPointSize(2.0);
    circle(30);
    circle(930);


    if(flag3==0){
        screen();
    }

    glFlush();
    glutSwapBuffers();
}

void mov(void){
    // Movement logic for 'a' (shark) and 'aa' (whale) - this part remains unchanged
    if(a >= -500)
        a = a - 7;
    else
        a = 700;

    if(a < -500){
        aa = aa - 100;
    }

    if(aa < -251){
        aa = 100;
    }

    if(b >= -950)
        b = b - 8.0;
    else
        b = 1000;

    if(b > 1000){
        // Change the direction of bb by decrementing it instead of incrementing
        bb = bb -150;
    }

    if(bb < -251){ // Adjust the condition for the lower limit
        bb = 50;
    }

    // Movement logic for 's' (shark's y-axis) and 'ss' (whale's y-axis)
    if(s >= -700)
        s = s - 9;
    else
        s = 700;

    if(s < -700){
        ss = ss - 250;
    }

    if(ss < -251){
        ss = 50;
    }
    if(w >= -700)
    w = w - 2;
    else
    w = 700;


    if(w < -700){
    ww = ww - 250;
    }

    if(ww < -251){
    ww = 50;
    }
}

void create_menu(void){

     glutCreateMenu(menu);
     glutAttachMenu(GLUT_LEFT_BUTTON);
     glutAttachMenu(GLUT_RIGHT_BUTTON);
     glutAddMenuEntry("move", 1);
     glutAddMenuEntry("stop", 2);
     glutAddMenuEntry("back", 3);
     glutAddMenuEntry("quit", 4);

}

void menu(int val){
    switch (val) {
        case 1:
            if(flag4==1 && moving ==0)
                moving = 1;
            break;
        case 2:
            glutIdleFunc(NULL);
            glutDisplayFunc(display);
            moving = 0;
            break;
        case 3:
            moving = 0;
            flag3=0;
            flag4=0;
            screen();
            break;
        case 4: exit(0);
            break;

    }
}

void speed()
{
a=a-9.0;
s=s-10;
b=b+10;
}

void slow()
{
a=a-0.0001;
}

void key(unsigned char k,int x,int y)
{
if(k=='i')
        glutIdleFunc(speed);

if(k=='d'){
        glutIdleFunc(slow);
}

if(k=='p'){
        flag3=1;
        flag4=1;
}

}

void helloF(){
    glClear(GL_COLOR_BUFFER_BIT);
    pb1();
    pb2();
    pb();
    plant();
    Shark();
}
int main(int argc,char **argv)
{
glutInit(&argc,argv);
glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
    glutInitWindowPosition(0,0);
    glutInitWindowSize(1200,600);
    glutCreateWindow("Andrew");
    init();
    glutReshapeFunc(reshape);
    glutKeyboardFunc(key);
    //glutDisplayFunc(helloF);
    glutDisplayFunc(display);
    create_menu();
    glutMainLoop();
}


