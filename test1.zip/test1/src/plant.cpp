/*
 * plant.cpp
 *
 *  Created on: Dec 5, 2023
 *      Author: seho3370
 */

#include "plant.h"


void plant3L(int x1, int x2, int m) {
    int dis = x2 - x1;
    dis = dis / 3;
    glColor3ub(40, 170, 5);
    glBegin(GL_POLYGON);
    glVertex2f(x1, 14);  // Adjust the y-coordinate
    glVertex2f(x1 - 10, m - 10 + 14);  // Adjust the y-coordinate
    glColor3f(0.0, 0.5, 0.0);
    glVertex2f(x1 + dis, 15 + 14);  // Adjust the y-coordinate
    glVertex2f(x1 + ((x2 - x1) / 2), m + 50);  // Adjust the y-coordinate
    glVertex2f(x2 - dis, 15 + 14);  // Adjust the y-coordinate
    glVertex2f(x2 + 12, m + 10 + 14);  // Adjust the y-coordinate
    glVertex2f(x2, 14);  // Adjust the y-coordinate
    glEnd();
}



void plant2L(int x1, int x2, int h1, int h2){

    glColor3ub( 60,170,15);
    glBegin(GL_POLYGON);
    glVertex2f(x1,30);
    glVertex2f(x1-20,h1+30);
    glColor3f(0.0,0.3,0.0);
    glVertex2f(x2,30);
    glVertex2f(x1+15,h2+30);
    glEnd();
}


void plant()
{
    plant2L(50,40,40,60);
    plant2L(95,85,50,60);
    plant2L(120,110,45,65);
    plant2L(70,60,60,40);
    plant2L(140,130,43,60);
    plant2L(950,940,40,50);
    plant2L(870,860,50,60);
    plant2L(470,460,40,50);
    plant2L(490,480,55,65);
    plant2L(520,510,40,50);
    plant2L(540,530,50,60);
    plant2L(700,690,40,50);
    plant2L(730,720,55,65);
    plant2L(795,785,40,50);

    plant3L(10,20,60);
    plant3L(160,170,50);
    plant3L(310,320,70);
    plant3L(435,445,60);
    plant3L(750,760, 55);
    plant3L(820,830,80);
    plant3L(900,910, 55);
}

void drawSand() {
    glColor3f(0.8, 0.8, 0.6);  // Sand color
    glBegin(GL_QUADS);
    glVertex2f(0, 0);
    glVertex2f(1100, 0);
    glVertex2f(1100, 50);  // Adjust the height of the sand as needed
    glVertex2f(0, 50);
    glEnd();
}
